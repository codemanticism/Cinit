# CCinit
Documentation on the following Github repo: https://github.com/codemanticism/CCinit.
